# DSA 4.1 Makros für Foundry VTT

**WARNUNG: EXPERIMENTELL UND UNGETESTET - Dieses Modul befindet sich derzeit in der Entwicklung und wurde noch nicht gründlich getestet. Benutzung auf eigene Gefahr!**
